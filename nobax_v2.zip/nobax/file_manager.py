"""Workspace-sandboxed file manager with automatic backups and undo support."""

from __future__ import annotations

import json
import os
import shutil
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from config import BACKUP_DIR, ConfigManager, ensure_data_dirs

MANIFEST_FILE = BACKUP_DIR / "manifest.json"
IGNORED_DIRS = {".git", "__pycache__", ".nobax", "node_modules", ".venv", "venv"}


@dataclass
class FileOpResult:
    ok: bool
    message: str
    rel_path: str = ""
    full_path: Path | None = None
    content: str = ""
    backup_path: Path | None = None


class FileManager:
    def __init__(self, config: ConfigManager) -> None:
        ensure_data_dirs()
        self.config = config
        self.manifest_path = MANIFEST_FILE
        if not self.manifest_path.exists():
            self._save_manifest([])

    @property
    def workspace(self) -> Path:
        return self.config.get_workspace_path()

    def resolve_safe_path(self, user_path: str) -> Path:
        cleaned = user_path.strip()
        if not cleaned:
            raise ValueError("Nama atau path file tidak boleh kosong.")
        ws_root = self.workspace.resolve()
        candidate = Path(cleaned)
        resolved = candidate.resolve() if candidate.is_absolute() else (ws_root / candidate).resolve()
        if not resolved.is_relative_to(ws_root):
            raise PermissionError(
                f"Akses ditolak: '{user_path}' berada di luar direktori kerja ({ws_root})."
            )
        return resolved

    def to_rel_path(self, full_path: Path) -> str:
        try:
            return str(full_path.resolve().relative_to(self.workspace.resolve()))
        except ValueError:
            return full_path.name

    def _load_manifest(self) -> list[dict[str, str]]:
        try:
            data = json.loads(self.manifest_path.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except (OSError, json.JSONDecodeError):
            return []

    def _save_manifest(self, entries: list[dict[str, str]]) -> None:
        self.manifest_path.parent.mkdir(parents=True, exist_ok=True)
        self.manifest_path.write_text(
            json.dumps(entries[-50:], indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    def create_backup(self, target_path: Path, action: str = "overwrite") -> Path | None:
        if not target_path.exists() or not target_path.is_file():
            return None
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        token = uuid.uuid4().hex[:6]
        safe_name = target_path.name.replace(os.sep, "_")
        bak_path = BACKUP_DIR / f"{stamp}_{token}_{safe_name}.bak"
        shutil.copy2(target_path, bak_path)
        entries = self._load_manifest()
        entries.append(
            {
                "backup_file": str(bak_path),
                "original_path": str(target_path.resolve()),
                "rel_path": self.to_rel_path(target_path),
                "action": action,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
        )
        self._save_manifest(entries)
        return bak_path

    def undo_last(self) -> FileOpResult:
        entries = self._load_manifest()
        while entries:
            last = entries.pop()
            bak_file = Path(last.get("backup_file", ""))
            orig_file = Path(last.get("original_path", ""))
            rel_path = last.get("rel_path", orig_file.name)
            if bak_file.exists() and orig_file:
                try:
                    orig_file.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(bak_file, orig_file)
                    bak_file.unlink(missing_ok=True)
                    self._save_manifest(entries)
                    return FileOpResult(
                        ok=True,
                        message=(
                            f"Perubahan terakhir pada '{rel_path}' berhasil dibatalkan "
                            f"(backup {last.get('timestamp', '')})."
                        ),
                        rel_path=rel_path,
                        full_path=orig_file,
                    )
                except OSError as exc:
                    self._save_manifest(entries)
                    return FileOpResult(ok=False, message=f"Gagal memulihkan backup '{rel_path}': {exc}")
        self._save_manifest([])
        return FileOpResult(ok=False, message="Tidak ada riwayat backup yang tersedia untuk dibatalkan (/undo).")

    def list_backups(self) -> list[dict[str, str]]:
        return [item for item in self._load_manifest() if Path(item.get("backup_file", "")).exists()]

    def read_file(self, user_path: str) -> FileOpResult:
        try:
            target = self.resolve_safe_path(user_path)
        except (ValueError, PermissionError) as exc:
            return FileOpResult(ok=False, message=str(exc))
        if not target.exists():
            return FileOpResult(ok=False, message=f"File tidak ditemukan: '{user_path}' di workspace {self.workspace}.")
        if not target.is_file():
            return FileOpResult(ok=False, message=f"Path '{user_path}' adalah direktori, bukan file.")
        try:
            raw = target.read_bytes()
            if b"\x00" in raw[:4096]:
                return FileOpResult(ok=False, message=f"File '{user_path}' adalah file biner.")
            text = raw.decode("utf-8", errors="replace")
            rel = self.to_rel_path(target)
            return FileOpResult(ok=True, message=f"Berhasil membaca '{rel}'.", rel_path=rel, full_path=target, content=text)
        except OSError as exc:
            return FileOpResult(ok=False, message=f"Gagal membaca file: {exc}")

    def write_file(self, user_path: str, content: str, action: str = "save") -> FileOpResult:
        try:
            target = self.resolve_safe_path(user_path)
        except (ValueError, PermissionError) as exc:
            return FileOpResult(ok=False, message=str(exc))
        if target.exists() and target.is_dir():
            return FileOpResult(ok=False, message=f"Tidak dapat menimpa direktori: '{user_path}'.")
        existed = target.exists()
        backup_path: Path | None = None
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            if existed:
                backup_path = self.create_backup(target, action=action)
            target.write_text(content, encoding="utf-8")
            rel = self.to_rel_path(target)
            bak_note = " (backup otomatis dibuat)" if backup_path else ""
            return FileOpResult(
                ok=True,
                message=f"File '{rel}' berhasil disimpan{bak_note}.",
                rel_path=rel,
                full_path=target,
                content=content,
                backup_path=backup_path,
            )
        except OSError as exc:
            return FileOpResult(ok=False, message=f"Gagal menyimpan file: {exc}")

    def list_files(self, subpath: str = "") -> tuple[bool, str, list[dict[str, str]]]:
        try:
            base = self.resolve_safe_path(subpath) if subpath.strip() else self.workspace
        except (ValueError, PermissionError) as exc:
            return False, str(exc), []
        if not base.exists() or not base.is_dir():
            return False, f"Direktori tidak ditemukan: '{subpath}'.", []
        items: list[dict[str, str]] = []
        try:
            for root, dirs, files in os.walk(base):
                dirs[:] = sorted(d for d in dirs if d not in IGNORED_DIRS and not d.startswith("."))
                root_path = Path(root)
                rel_dir = self.to_rel_path(root_path)
                if rel_dir != ".":
                    items.append({"type": "DIR", "path": rel_dir + "/", "size": "-", "modified": "-"})
                for fname in sorted(files):
                    if fname.startswith("."):
                        continue
                    fpath = root_path / fname
                    try:
                        if fpath.resolve().is_relative_to(BACKUP_DIR.resolve()):
                            continue
                    except ValueError:
                        pass
                    items.append(
                        {
                            "type": fpath.suffix.lstrip(".").upper() or "FILE",
                            "path": self.to_rel_path(fpath),
                            "size": self._fmt_size(fpath.stat().st_size),
                            "modified": "-",
                        }
                    )
        except OSError as exc:
            return False, f"Gagal membaca isi direktori: {exc}", []
        return True, self.to_rel_path(base), items

    @staticmethod
    def _fmt_size(num_bytes: int) -> str:
        if num_bytes < 1024:
            return f"{num_bytes} B"
        if num_bytes < 1024 * 1024:
            return f"{num_bytes / 1024:.1f} KB"
        return f"{num_bytes / (1024 * 1024):.1f} MB"
